<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<a  class="btn btn-primary" href="<?php echo site_url('taskcontroller/display_records');?>" >Display Records</a>
<style>
	.form {
		display: flex;
		flex-direction: column;
	}
</style>
<body>
	
<form  method="post" action="<?php echo site_url('taskcontroller/insert');?>">
<div class="form">
		<input type="hidden" id="id">
		<label>Name<input type="text"  name="name" id="name"></label>
		<label>DOB<input type="date" name="dob" id="dob"></label>
		<label>Designation<input type="text" name="des" id="des"></label>
		<label>Qualification<input type="text"  name="qua" id="qua"></label>
		<label>Gender:</lable>
		<lable>Male<input type="radio" name="gender" value="male"></label><label>Female<input type="radio" name="gender" value="female"></label>
		<label>Email<input type="email"  name="email" id="email"></label>
		<label>Is Relocate<input type="hidden" value="no" name="loc" id="loc"><input type="checkbox" value="yes" name="loc" id="loc"></label>
		<label>Mobile<input type="text"  name="mo" id="mo"></label>
		<label><button type="submit"  id="save">Save</button></label>
	</div>
	</form>


</body>
</html>
