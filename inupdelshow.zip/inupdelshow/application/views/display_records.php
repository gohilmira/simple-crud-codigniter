<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
     <br>        
     <br>        
     <br><a  class="btn btn-primary" href="<?php echo site_url('taskcontroller/index');?>" >Add</a>
  <table class="table">
    <thead>
      <tr>
        <th>name</th>
        <th>dob</th>
        <th>des</th>
        <th>qua</th>
        <th>gender</th>
        <th>email</th>
        <th>loc</th>
        <th>mo</th>
        <th colspan="2">Action</th>
      </tr>
    </thead>
    <tbody>
		<?php
	$count=1;
foreach ($data as $row) {
	?>
      <tr>
        <td><?php echo $row->name; ?></td>
        <td><?php echo $row->dob; ?></td>
        <td><?php echo $row->des; ?></td>
        <td><?php echo $row->qua; ?></td>
        <td><?php echo $row->gender; ?></td>
        <td><?php echo $row->email; ?></td>
        <td><?php echo $row->loc; ?></td>
        <td><?php echo $row->mo; ?></td>
		<?php echo "<td><a href='delete?id=".$row->id."'><i class='fa fa-trash-o' style='font-size: 25px;'></i>Delete</a>
                        <a href='fetch?id=".$row->id."'><i class='fa fa-edit' style='font-size: 25px;'></i>Update</a>
                    </td>";
        ?>
       
      </tr>
     <?php }
	 ?>
    </tbody>
  </table>
</div>

</body>
</html>

