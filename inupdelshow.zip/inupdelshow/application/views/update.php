<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<style>
	.form {
		display: flex;
		flex-direction: column;
	}
</style>
<body>
<?php
       foreach ($data as $row) {
     
       ?>
<form  method="post" action="<?php echo site_url('taskcontroller/update');?>">
<div class="form">
		<input type="hidden" id="uid" name="uid" value="<?php echo $row->id; ?>">
		<label>Name<input type="text"  name="name" id="name" value="<?php echo $row->name; ?>"</label><br>
		<label>DOB<input type="date" name="dob" id="dob" value="<?php echo $row->dob; ?>"></label><br>
		<label>Designation<input type="text" name="des" id="des" value="<?php echo $row->des; ?>"></label><br>
		<label>Qualification<input type="text"  name="qua" id="qua" value="<?php echo $row->qua; ?>"></label><br>
		<label>Gender:</lable><br>
		<lable>Male<input type="radio" name="gender" value="male" <?php if($row->gender == "male"){echo 'checked';} ?>></label>
		<label>Female<input type="radio" name="gender" value="female" <?php if($row->gender == "female"){echo 'checked';}?>></label><br>
		<label>Email<input type="email"  name="email" id="email" value="<?php echo $row->email; ?>"></label><br>
		<label>Is Relocate<input type="hidden" value="no" name="loc" id="loc"><input type="checkbox" value="yes" name="loc" id="loc" <?php if($row->loc == "yes"){echo 'checked';}?>></label><br>
		<label>Mobile<input type="text"  name="mo" id="mo" value="<?php echo $row->mo; ?>"></label><br>
		<label><button type="submit"  id="save">Update</button></label><br>
	</div>
	</form>
	


<?php
      }
     
       ?></body>
	   </html>

